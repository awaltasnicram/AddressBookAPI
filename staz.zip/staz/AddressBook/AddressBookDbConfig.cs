﻿
namespace AddressBook

{
    public class AddressBookDbConfig
    {
        public string Database_Name { get; set; }
        public string Addresses_Collection_Name { get; set; }
        public string Connection_String { get; set; }
    }
}

